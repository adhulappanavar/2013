aadhaar
=======

Utilities for indexing and analyzing Aadhaar's public datasets.
